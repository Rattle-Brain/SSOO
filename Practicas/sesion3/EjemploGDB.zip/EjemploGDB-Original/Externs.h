#include "Defs.h"

extern int Prime[MaxPrimes];